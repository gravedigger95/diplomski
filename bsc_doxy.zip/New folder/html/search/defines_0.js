var searchData=
[
  ['_5fwinsock_5fdeprecated_5fno_5fwarnings',['_WINSOCK_DEPRECATED_NO_WARNINGS',['../__module3_8h.html#adfc8f90f3a8caa8423099cf36ff214f1',1,'_WINSOCK_DEPRECATED_NO_WARNINGS():&#160;_module3.h'],['../module3_8h.html#adfc8f90f3a8caa8423099cf36ff214f1',1,'_WINSOCK_DEPRECATED_NO_WARNINGS():&#160;module3.h']]]
];
