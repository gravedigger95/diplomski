var searchData=
[
  ['getmsgq_5fbutton',['getMsgQ_button',['../class_main_window.html#a33fff3efd2a06d6df2e37219d44d9d20',1,'MainWindow']]],
  ['getshmem_5fbutton',['getShMem_button',['../class_main_window.html#a26663544e9c5a627b73df4d060a9a06a',1,'MainWindow']]]
];
