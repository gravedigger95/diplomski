var searchData=
[
  ['getfile',['getFile',['../class_main_window.html#ae312fe1c0640df073ef40d7fbab3e1f9',1,'MainWindow']]],
  ['getmsgq',['getMsgQ',['../class_main_window.html#af0e609b7bacc38e1f25151a55b589222',1,'MainWindow']]],
  ['getmsgqstatus',['getMsgQStatus',['../class_main_window.html#a0b1a3960102da5863d7d31570d2837b7',1,'MainWindow']]],
  ['getshmem',['getShMem',['../class_main_window.html#a707b068e9373c76cbb4d844b15d4b509',1,'MainWindow']]],
  ['getshmemstatus',['getShMemStatus',['../class_main_window.html#a491881163b44282206d1313243af5e2f',1,'MainWindow']]]
];
