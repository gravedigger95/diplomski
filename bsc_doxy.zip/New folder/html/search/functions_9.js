var searchData=
[
  ['sendroutinenum',['sendRoutineNum',['../class_module3.html#a17b4aac26b4f9d44ec48a8022913cc7a',1,'Module3::sendRoutineNum(int rNum)'],['../class_module3.html#a17b4aac26b4f9d44ec48a8022913cc7a',1,'Module3::sendRoutineNum(int rNum)']]],
  ['sharedmemalloc_5fmodule2',['sharedMemAlloc_module2',['../module_two_communication_8c.html#a99a7dd6823d02d0f1f5d9bcfedd08fc4',1,'sharedMemAlloc_module2(void):&#160;moduleTwoCommunication.c'],['../module_two_communication_8h.html#a99a7dd6823d02d0f1f5d9bcfedd08fc4',1,'sharedMemAlloc_module2(void):&#160;moduleTwoCommunication.c']]],
  ['startmodule',['startModule',['../class_module3.html#af03e3df56d29af941005a6c83717d8db',1,'Module3::startModule(int insertedNumber)'],['../class_module3.html#af03e3df56d29af941005a6c83717d8db',1,'Module3::startModule(int insertedNumber)']]]
];
