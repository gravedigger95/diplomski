var searchData=
[
  ['wakeup',['wakeup',['../structdiagnostic_data_msg_q.html#a8af90f2f6077250420f9c4830906a82f',1,'diagnosticDataMsgQ::wakeup()'],['../structdiagnostic_data_msg_q.html#a8af90f2f6077250420f9c4830906a82f',1,'diagnosticDataMsgQ::wakeup()']]]
];
