var searchData=
[
  ['jabber_5fdetect',['jabber_detect',['../structdiagnostic_data_sh_m.html#ac2b66edcfd19f4d451164ac0db6311ba',1,'diagnosticDataShM::jabber_detect()'],['../structdiagnostic_data_sh_m.html#ac2b66edcfd19f4d451164ac0db6311ba',1,'diagnosticDataShM::jabber_detect()']]]
];
