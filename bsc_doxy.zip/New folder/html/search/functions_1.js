var searchData=
[
  ['clearfile',['clearFile',['../class_main_window.html#abc60bc84ec0badc555d692af286f8053',1,'MainWindow']]]
];
