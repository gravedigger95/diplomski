var searchData=
[
  ['fpgabr_5far_5foffset',['FPGABR_AR_OFFSET',['../tttech_broad_r_reach_8c.html#a9ad86df1d1058bd64100438563dfffa9',1,'tttechBroadRReach.c']]],
  ['fpgabr_5fdr_5foffset',['FPGABR_DR_OFFSET',['../tttech_broad_r_reach_8c.html#a0fac0c169afbd5b4e41115545e59270c',1,'tttechBroadRReach.c']]]
];
