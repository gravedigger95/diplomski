var searchData=
[
  ['clear_5fmask',['CLEAR_MASK',['../module_one_read_eth_phy_8h.html#ae72e1fb9c55d5804aec7e9a342db7b34',1,'moduleOneReadEthPhy.h']]],
  ['clk_5fmgr_5fperpll_5femac0_5fclk',['CLK_MGR_PERPLL_EMAC0_CLK',['../tttech_broad_r_reach_8c.html#a58e088136e440393b8cc917362151e30',1,'tttechBroadRReach.c']]],
  ['clk_5fmgr_5fperpll_5femac1_5fclk',['CLK_MGR_PERPLL_EMAC1_CLK',['../tttech_broad_r_reach_8c.html#ab0715001c3b24126bc382f68a3d78e0d',1,'tttechBroadRReach.c']]],
  ['cnt_5fwrong_5fip',['cnt_wrong_IP',['../struct_b_r_diag_data.html#a547b4cf3fcd1d5686591da312e375e21',1,'BRDiagData']]],
  ['cnt_5fwrong_5ftcpport',['cnt_wrong_TCPport',['../struct_b_r_diag_data.html#acfd5368dd58e132b13062dbad9ae2dd8',1,'BRDiagData']]],
  ['cnt_5fwrong_5fudpport',['cnt_wrong_UDPport',['../struct_b_r_diag_data.html#a5835a6a7161d695e1724da1ce9185339',1,'BRDiagData']]],
  ['cnt_5fwrong_5fvlan',['cnt_wrong_VLAN',['../struct_b_r_diag_data.html#a12d116dc3607d10fe1e772435a064857',1,'BRDiagData']]],
  ['communication_5fstatus_5fregister',['COMMUNICATION_STATUS_REGISTER',['../module_one_read_eth_phy_8h.html#a7b3231c45827132795a985df98b30788',1,'moduleOneReadEthPhy.h']]],
  ['configuration_5fregister_5f1',['CONFIGURATION_REGISTER_1',['../module_one_handle_routines_8h.html#ad6a5f0870f87a830a9281a48c20d1967',1,'CONFIGURATION_REGISTER_1():&#160;moduleOneHandleRoutines.h'],['../module_one_read_eth_phy_8h.html#ad6a5f0870f87a830a9281a48c20d1967',1,'CONFIGURATION_REGISTER_1():&#160;moduleOneReadEthPhy.h']]],
  ['configuration_5fregister_5faccess_5fenabled',['CONFIGURATION_REGISTER_ACCESS_ENABLED',['../module_one_handle_routines_8h.html#a0efb45398b365632ce15a87565c07330',1,'moduleOneHandleRoutines.h']]],
  ['cyclone_5faddress_5fregister_5foffset',['CYCLONE_ADDRESS_REGISTER_OFFSET',['../module_one_startup_8h.html#ab479861fbeb542421a059450bf96190b',1,'moduleOneStartup.h']]],
  ['cyclone_5fdata_5fregister_5foffset',['CYCLONE_DATA_REGISTER_OFFSET',['../module_one_startup_8h.html#a2ee53712d2a6b91d23d9c32bb5e0a141',1,'moduleOneStartup.h']]]
];
