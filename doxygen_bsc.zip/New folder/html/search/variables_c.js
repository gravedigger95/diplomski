var searchData=
[
  ['signal_5fquality',['signal_quality',['../structdiagnostic_data_msg_q.html#a2cbee01deb307a445abc8ef0dfdd56f3',1,'diagnosticDataMsgQ']]],
  ['status_5froutine',['status_routine',['../struct_b_r_diag_data.html#a29727be81df0a5cab888e7c16c78f152',1,'BRDiagData']]],
  ['status_5fval',['status_val',['../struct_b_r_diag_data.html#a1b6c0080fff5bddfc534cf9b50d52564',1,'BRDiagData']]]
];
