var searchData=
[
  ['sharedmemalloc_5fmodule2',['sharedMemAlloc_module2',['../module_two_communication_8c.html#a99a7dd6823d02d0f1f5d9bcfedd08fc4',1,'sharedMemAlloc_module2(void):&#160;moduleTwoCommunication.c'],['../module_two_communication_8h.html#a99a7dd6823d02d0f1f5d9bcfedd08fc4',1,'sharedMemAlloc_module2(void):&#160;moduleTwoCommunication.c']]]
];
