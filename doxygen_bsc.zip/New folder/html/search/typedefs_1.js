var searchData=
[
  ['tja1100_5flinkfail_5fcount_5ft',['TJA1100_LINKFAIL_COUNT_t',['../tttech_broad_r_reach_8h.html#a856f0f5d2721021c2d7cabda96a34c67',1,'tttechBroadRReach.h']]],
  ['tja1100_5floc_5frcvr_5fcounter_5ft',['TJA1100_LOC_RCVR_COUNTER_t',['../tttech_broad_r_reach_8h.html#abe0ea99b573f642635b5711d6c8230c5',1,'tttechBroadRReach.h']]],
  ['tja1100_5fphy_5fid_5f1_5ft',['TJA1100_PHY_ID_1_t',['../tttech_broad_r_reach_8h.html#a8a0457bddbf65b1d060e4e3ea6802a79',1,'tttechBroadRReach.h']]],
  ['tja1100_5fphy_5fid_5f2_5ft',['TJA1100_PHY_ID_2_t',['../tttech_broad_r_reach_8h.html#a57f35f382841e42ae2fc7a4954bce6ee',1,'tttechBroadRReach.h']]],
  ['tja1100_5fphyad4to0_5ft',['TJA1100_PHYAD4to0_t',['../tttech_broad_r_reach_8h.html#ae4892b3e260f4a7dcf8629765ac91572',1,'tttechBroadRReach.h']]],
  ['tja1100_5frem_5frcvr_5fcounter_5ft',['TJA1100_REM_RCVR_COUNTER_t',['../tttech_broad_r_reach_8h.html#aa9147a08db494802d6956b936563edbe',1,'tttechBroadRReach.h']]],
  ['tja1100_5frevision_5fno_5ft',['TJA1100_REVISION_No_t',['../tttech_broad_r_reach_8h.html#a77f4bdf460a8c968d593b160f2989bf5',1,'tttechBroadRReach.h']]],
  ['tja1100_5fsym_5ferr_5fcnt_5ft',['TJA1100_SYM_ERR_CNT_t',['../tttech_broad_r_reach_8h.html#ab2aa0de21bfb7dd87a25000627df86b0',1,'tttechBroadRReach.h']]],
  ['tja1100_5ftype_5fno_5ft',['TJA1100_TYPE_No_t',['../tttech_broad_r_reach_8h.html#a14c46db41876f09bcb11ead37d8f2963',1,'tttechBroadRReach.h']]]
];
