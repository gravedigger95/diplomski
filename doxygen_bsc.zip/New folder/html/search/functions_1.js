var searchData=
[
  ['initcommunication',['initCommunication',['../module_two_server_8c.html#a9e672e3d06cb60f46dc825ed114c95f6',1,'initCommunication(void):&#160;moduleTwoServer.c'],['../module_two_server_8h.html#a9e672e3d06cb60f46dc825ed114c95f6',1,'initCommunication(void):&#160;moduleTwoServer.c']]]
];
