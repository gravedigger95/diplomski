var indexSectionsWithContent =
{
  0: "_abcdefghijlmnprstuvw",
  1: "bde",
  2: "mt",
  3: "_imprstuv",
  4: "_bcdeijlmnprstw",
  5: "st",
  6: "bt",
  7: "bt",
  8: "abcdefghijlmnprstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

